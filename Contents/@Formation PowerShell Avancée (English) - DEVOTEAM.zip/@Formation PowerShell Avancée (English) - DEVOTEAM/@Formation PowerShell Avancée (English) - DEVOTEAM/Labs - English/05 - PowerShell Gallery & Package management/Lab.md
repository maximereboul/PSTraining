# PowerShell Gallery

Main Goal : Know how to use the PowerShell Gallery hosted by Microsoft

1. Update the PowershellGet module to the latest version
   
   Because Windows PowerShell 5.1 is not configured by default to use TLS 1.2 we must do this before accessing to the gallery:

```PowerShell
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

# First we need to install the NuGet provider
Install-PackageProvider -Name NuGet -Force

# Then we can update the module
Install-Module PowerShellGet -AllowClobber -Force
```
2.	List the cmdlets contained in the PowerShellGet module

3.	Do some searches in the PowerShell Gallery. For instance, search for: QRCode module, Az module, etc.

4.	Install the QRCodeGenerator module or the PSWordCloud module and try it.

5.	Explore the gallery with your internet browser: https://www.powershellgallery.com/

6.	Observe the instructions to publish a module.