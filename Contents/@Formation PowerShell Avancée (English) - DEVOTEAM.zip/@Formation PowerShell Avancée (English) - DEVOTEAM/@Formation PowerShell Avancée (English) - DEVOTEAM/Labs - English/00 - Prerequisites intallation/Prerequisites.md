# Installation prerequisites for your client machine (Windows 10 or 11)

## VSCode installation

Start PowerShell, then write:
```
winget install Microsoft.VisualStudioCode
```

Start VSCode and install the PowerShell Extension.  
You'll be asked to choose your color theme. You can select "PowerShellISE" if you like the colors.

If you want to change your theme later, go in the menu File/Preferences/Color Theme then choose "Dark"

## Terminal Windows Installation
Start PowerShell, then write:

```
winget install Microsoft.WindowsTerminal
```

## PowerShell 7 installation
You could either:
* Download and install the binary file from : https://github.com/powershell/powershell
* Use WinGet : `winget install Microsoft.PowerShell`
