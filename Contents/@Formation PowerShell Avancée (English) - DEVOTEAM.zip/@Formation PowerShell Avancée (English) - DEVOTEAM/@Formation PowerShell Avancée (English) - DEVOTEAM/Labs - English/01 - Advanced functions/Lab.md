# Advanced functions lab

## Main goal


Create a function that aimed at creating well structured log files with a timestamp.  

Your function must accept the following parameters:
   - A file name
   - An information type to write (for instance : Information, Warning, Error)
   - A field delimiter (for instance : a comma, a tab, a semi-colon, etc.)
   - A switch which goal is to show the log message in the console (or not)

When you'll be displaying the log messages in the console, depending on the type (Information, Warning, or Error), the color should be different.
For example, yellow for a Warning message, red for an error message, cyan for an Information message.  
Every log entry in the log file must be timestamped (and start by it).  

Your function must generate a header on the beginning of the log file and a footer at the end of the file when "closing" the log session.

The header must contain the following metadata: 
   - The computer name,
   - The user name,
   - The OS version of the computer running the script,
   - The current date and time.

The footer must contain:
   - The current date and time,
   - The elapsed time between the time the header and the footer was written. This information will be useful to determine the total execution time of the script.

Utilization examples of that your function should look like:

```Powershell
# Log file initialization (writing the header)
Write-Log -Filepath C:\logs\mylog.txt -Header -ToScreen

# Writing an information message to the log file and display it to the console
Write-Log -Category Information -Message 'This is an information message' -Filepath C:\logs\mylog.txt -ToScreen

# Writing an information message to the log file without displaying it to the console
Write-Log -Category Information -Message 'This is an information message' -Filepath C:\logs\mylog.txt

# Closing the log file (writing the footer)
Write-Log -Filepath C:\logs\mylog.txt -Footer -ToScreen
```

Log file sample of what your function should generate:
```
+----------------------------------------------------------------------------------------+
Script fullname          : C:\Users\Arnaud\Documents\GitRepo\Temp\script_example.ps1
When generated           : 2022-01-14 12:23:16
Current user             : DESKTOP-31O7OD0\Arnaud
Current computer         : DESKTOP-31O7OD0
Operating System         : Microsoft Windows 10 Entreprise 
OS Architecture          : 64 bits
+----------------------------------------------------------------------------------------+

2022-01-14 12:23:16; INF; This is a regular information message. Will be displayed in Cyan color in the console.
2022-01-14 12:23:18; WAR; This is a warning message. Will be displayed in Yellow color in the console.
2022-01-14 12:23:19; ERR; This is an error message. Will be displayed in red color in the console.

+----------------------------------------------------------------------------------------+
End time                 : 2022-01-14 12:23:25
Total duration (seconds) : 9
Total duration (minutes) : 0.15
+----------------------------------------------------------------------------------------+
```

Your function must also accept data passed thru the pipeline. Hence it should be usable this way:

```Powershell
# Writing an information log message using the pipeline
'This is a regular information message.' | Write-Log -Category Information -Filepath C:\logs\mylog.txt
```

Your script being made with a professional quality, you should validate each parameter entry. For instance, you should reject every value which is not among : Information, Warning, Error for the -Category parameter.

You would have probably understood that your script must also be able to handle multiple parameter sets. Indeed, it should not be possibile to call the -Header parameter along with -Footer or -Category.

**Bonus 1: Define the Path alias on the -FilePath parameter**    
**Bonus 2: Implement the -WhatIf common parameter**  
