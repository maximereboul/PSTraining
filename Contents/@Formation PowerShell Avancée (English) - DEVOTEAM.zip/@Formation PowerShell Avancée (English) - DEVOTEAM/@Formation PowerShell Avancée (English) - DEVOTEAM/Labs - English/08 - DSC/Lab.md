# Desired State Configuration

__Objectif :__ Découvrir les possibilités offertes par DSC

1. Lister les commandes disponibles dans le module PSDesiredStateConfiguration.

1. Observez la configuration du LCM sur votre machine, puis déterminez si votre ordinateur est configuré pour prendre en charge le mode Push ou le mode Pull. 

1. Créez une configuration DSC afin de : 
   - Créer un fichier vide dans le répertoire C:\Program Files\myDirectory\myFile.txt
   - Installer la fonctionnalité Windows (ou rôle) de votre choix
   - Configurer le service Windows Audio en mode de démarrage Automatique
   - Configurer le service Windows Audio pour qu'il soit toujours démarré