# Configuration d'une Repository PowerShell privée

## Repository locale en mode Fichier

1. Créer un répertoire et le partager

```PowerShell
$RepositoryName = 'myPSPrivateRepo'
$path = 'C:\' + $RepositoryName
New-Item -Path $path -ItemType Directory
New-SmbShare -Name $RepositoryName -Path $path
```

2. Enregistrer la repository localement et la truster
```PowerShell
Register-PSRepository -Name $RepositoryName -SourceLocation $path -PublishLocation $path -ScriptSourceLocation $path

Set-PSRepository -Name $RepositoryName -InstallationPolicy Trusted
```


3. Publier un module (exemple : myModule)

```PowerShell
Publish-Module -Name myModule -RequiredVersion 1.0.0.1 -Repository $RepositoryName
```


## Repository Cloud avec MyGet

### Installation de la repository

1. Installer MyGet ou utiliser la version SAAS
2. Configurer la repo Nuget et lui donner un nom
3. Récupérer la clé d'API

### Configurer PowerShell pour lui faire reconnaître la répo privée
```Powershell
$PSGalleryPublishUri = 'https://www.myget.org/F/<Nom de la repository>/api/v2/package'
$PSGallerySourceUri = 'https://www.myget.org/F/<Nom de la repository>/api/v2'
$APIkey = '62355db5-2d26-45d0-8f4b-6ee1bced8aa3'
Register-PSRepository -Name MyGetFeed -SourceLocation $PSGallerySourceUri -PublishLocation $PSGalleryPublishUri

```

### Publier un module dans la repo
```Powershell
Publish-module -Name ezlog -Repository MyGetFeed -NuGetApiKey $APIKey -verbose
```

### Vérifier la présence du module dans la repo
```Powershell
find-module -Repository myGetFeed
```