﻿$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sut = (Split-Path -Leaf $MyInvocation.MyCommand.Path) -replace '\.Tests\.', '.'
. "$here\$sut"

Describe Get-CharacterMeasurement {

   $Str = 'Bonjour les gens'

   Context Common {
      It 'Should return a String' {
         Get-CharacterMeasurement -Str $Str | Should BeOfType [String]
      }

      It 'Should have a square brackets at the end of the string' {
         #....
      }

      It 'Should contain a number inside the brackets' {
         #...
      }
   }

   Context 'Parameter validation' {
      It 'Should implement an ignoreWhiteSpaceSwitch' {
         (Get-Command Get-CharacterMeasurement | Select-Object -Expand Parameters).keys -contains 'ignoreWhiteSpace' | Should Be $True
      }
   }
}