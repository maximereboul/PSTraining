﻿$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sut = (Split-Path -Leaf $MyInvocation.MyCommand.Path) -replace '\.Tests\.', '.'
. "$here\$sut"


Describe Export-ADUser {


  Context 'user not found' {

      Mock Get-ADUser { throw 'Not found' }
 
      It 'should say so' {
        Export-ADUser -Identity unknown | Should Be 'USER NOT FOUND'
      }
  }

  Context 'normal user' {

      Mock Get-ADUser { [PSCustomObject]@{
                                            FirstName = 'John'
                                            Name      = 'Doe'
                                            Mail      = 'j.doe@example.com'
                                        } 
      }

      It 'should format the user name and email' {
        Export-ADUser -Identity JohnDoe | Should Be 'John Doe <j.doe@example.com>'
      }
  }

  Context 'emailless user' {

     Mock Get-ADUser { [PSCustomObject]@{
                                            FirstName = 'John'
                                            Name      = 'Doe'
                                            Mail      = ''
                                        } 
     }

     It 'should format the user name only' {
        Export-ADUser -Identity JohnDoe | Should Be 'John Doe'
     }
  }
}