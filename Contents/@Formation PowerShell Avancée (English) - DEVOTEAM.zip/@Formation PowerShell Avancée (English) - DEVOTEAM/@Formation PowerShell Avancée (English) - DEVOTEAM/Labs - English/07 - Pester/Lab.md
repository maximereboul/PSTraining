# Pester

__Objectif :__ Vous familiariser avec les tests et comprendre leur intérêt dans la vie quotidienne.

1.	Familiarisez-vous avec la fonction `Get-CharacterMeasurement` en l’exécutant et/ou en observant son code afin de comprendre son fonctionnement.

2.	Placez-vous dans le répertoire du script à tester, puis utilisez la commande `Invoke-Pester` afin d’initier le démarrage des tests.

3.	Complétez le fichier de tests `Get-CharacterMeasurement.Tests.ps1` car celui-ci comprend un certain nombre de tests qui n’ont pas encore été implémentés.

4.	Ajoutez un test afin de tester que la longueur de la chaine retournée par la fonction `Get-CharacterMeasurement` soit non vide.

4. Ajoutez un test afin de vérifier que la chaine retournée possède bien une valeur entre crochet à la fin de cette dernière.

5.  Observez le second exemple de script nommé `Export-ADUser.ps1`ainsi que son fichier de tests associé.

6.	Utilisez la commande `New-Fixture` afin de démarrer un nouveau projet de script avec les tests PESTER associés.

7.	Le projet que vous allez faire maintenant va consister à valider la bonne configuration de votre ordinateur.  
Ecrivez des tests pour tester :  
a.	Que le service Spooler existe,  
b.	Que le service Spooler soit configuré en mode démarrage automatique,  
c.	Que le service Spooler soit démarré,  
d.	Qu’une clé de registre (celle de votre choix) soit bien présente sur la machine,  
e.	Que les ports d’écoute de WinRM (5985 et 5986) soient bien ouverts.

8. Installez le module *PoshSpec* à partir de la PowerShell Gallery et transformez votre script Pester précédent en vue de le simplifier.