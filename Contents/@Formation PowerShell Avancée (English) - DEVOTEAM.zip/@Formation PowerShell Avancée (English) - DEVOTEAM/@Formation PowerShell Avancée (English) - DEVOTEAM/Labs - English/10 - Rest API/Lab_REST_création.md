﻿# Lab REST API

L'objectif de ce lab est de créer une API Rest...

Le fichier Stocklist.csv fourni est un stock de produits vestimentaires. Exposez une API Rest afin de pouvoir facilement récupérer les données.

Proposez les fonctionnalités suivantes :
   - Filtre sur genre (homme ou femme)
   - Filtre sur la marque
   - Authentification par clé d'API

Implémentez l'URL suivante : 
```
http://localhost:8080/material?division=quiksilver&gender=women
```

## ...avec le module POLARIS
/!\ N'oubliez pas qu'avec Polaris vous ne pouvez pas faire tourner l'API et la consommer avec la même console PowerShell.

1. Visitez la page [Github du projet Polaris](https://github.com/PowerShell/Polaris) afin d'en apprendre d'avantage sur le projet et pour bien démarrer.
2. Implémentez le service REST

## ...avec le module PowerShell Universal Dashboard

1. Visitez la documentation produit [Documentation REST API](https://docs.universaldashboard.io/rest-apis) afin d'en apprendre d'avantage sur le projet et pour bien démarrer.
2. Implémentez le service REST
