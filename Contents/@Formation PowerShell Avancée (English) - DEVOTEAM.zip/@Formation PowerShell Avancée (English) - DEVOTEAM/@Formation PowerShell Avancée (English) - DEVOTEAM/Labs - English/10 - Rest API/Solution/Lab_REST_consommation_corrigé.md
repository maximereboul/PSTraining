﻿# Lab REST API

L'objectif de ce lab est de vous familiariser avec la consommation d'API REST.

## Bac à sable : jsonplaceholder.typicode.com
- Observez l'aide de la commande Invoke-RestMethod

- Vous allez consommer l'API REST du site https://jsonplaceholder.typicode.com. Ce site est un site "bac à sable" dont l'objectif est de se familiariser avec REST. Je vous invite à visiter la page d'accueil de ce site pour vous familiariser avec les usages de l'API REST qu'il propose.

- Effectuez une request de type GET sur l'URI : https://jsonplaceholder.typicode.com/todos/1

```PowerShell
Invoke-RestMethod -Method Get -Uri https://jsonplaceholder.typicode.com/todos/1
```

- Testez les autres ressources (posts, comments, users)

- Filtrez avec l'URI afin de ne récupérer que les posts de l'utilisateur 1

```PowerShell
# Récupération de tous les posts
Invoke-RestMethod -Method Get -Uri https://jsonplaceholder.typicode.com/posts

# Récupération des posts de l'utilisateur 1 uniquement
Invoke-RestMethod -Method Get -Uri https://jsonplaceholder.typicode.com/posts?userId=1

# Récupération de tous les commentaires
Invoke-RestMethod -Method Get -Uri https://jsonplaceholder.typicode.com/comments
# Récupération des commentaires de l'utilisateur dont l'adresse mail est 'Dolly@mandy.co.uk'
Invoke-RestMethod -Method Get -Uri https://jsonplaceholder.typicode.com/comments?email=Dolly@mandy.co.uk

# Envoi d'une requete POST pour créer un post
Invoke-RestMethod -Method Post -Uri 'https://jsonplaceholder.typicode.com/posts' -Body @{ 'title'='Hello from PowerShell';'body'='From Switzerland'; 'userId'='1' }

# Suppression d'un utilisateur
Invoke-RestMethod -Method Delete -Uri 'https://jsonplaceholder.typicode.com/posts/1'

# Modification d'un post
 Invoke-RestMethod -Method Put -Uri 'https://jsonplaceholder.typicode.com/posts/1' -Body @{ 'id'=1; 'title'='Hello';'body'='PowerShell'; 'userId'=1 }
```

## Tradons de la crypto monnaie
 A l'aide des instructions données sur le site de la plateforme de trading POLONIEX, récupérez les cours en temps réel des crypto monnaies telles que le Bitcoin
  - https://docs.poloniex.com

## Moteur de recherches des API REST

Visitez le site ANY-API (https://any-api.com). Celui-ci référence un grand nombre d'API Rest publiques. 
  N'hésitez pas à en choisir une ou deux et à tester.

## Le coin des cinéphiles

Sur le site omdbapi.com (base de données Cinématographique), récupérez une clé d'API et effectuez des requetes pour rechercher des films par titre.

Vous pouvez éventuellement essayer cette clé : 'apikey=d4f903ad'

```PowerShell
$APIKey = @{apikey='d4f903ad'}
# Test rapide de la clé
Invoke-RestMethod -Method Get -Uri 'http://www.omdbapi.com/?i=tt3896198&apikey=d4f903ad'

# Récupère toutes les caractéristiques d'un film par son Id
Invoke-RestMethod -Method Get -Uri http://www.omdbapi.com/?i=tt3896198 -Body $APIKey

# Effectue une recherche sur le film Batman
(Invoke-RestMethod -Method Get -Uri http://www.omdbapi.com/?s=batman -Body $APIKey).search
```

6. Téléchargez la jaquette d'un film
```PowerShell
$URI = Invoke-RestMethod -Method Get -Uri http://www.omdbapi.com/?s=batman -Body $APIKey
$URI = $URI.search[0].Poster
Invoke-WebRequest -URI $URI -OutFile ./batman.jpg
```