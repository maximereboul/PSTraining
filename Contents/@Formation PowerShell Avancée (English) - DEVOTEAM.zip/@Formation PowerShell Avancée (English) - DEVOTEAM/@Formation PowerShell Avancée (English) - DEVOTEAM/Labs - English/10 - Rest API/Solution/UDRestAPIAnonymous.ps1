$Endpoint1 = New-UDEndpoint -Url "/material/:division:gender" -Method "GET" -Endpoint {
    Param ($division, $gender)

    $stock = Import-csv -Path "$PSScriptroot\STOCKLIST.csv" -Delimiter ';'
    if ($null -ne $division) {
        $stock = $stock | Where-Object {$_.'Division Desc' -eq $division}
    }

    if ($null -ne $gender) {
        $stock = $stock | Where-Object {$_.'PH1 - Gender Age Group' -eq $gender}
    }

    $stock | ConvertTo-Json
}

Get-UDRestApi | Stop-UDRestApi
Start-UDRestApi -Endpoint  $Endpoint1

Invoke-RestMethod -Method Get -Uri http://localhost/api/material?division=quiksilver