# Module creation

__Main goal :__ Create a module composed of all the scripts you made during the training.


1.	Find an appropriate name for your module (for instance: myCompanyLog)

2.	At the location that seems to suit you the best to store your module, create the hierarchy of folders and give your module the version number 1.0.0.

3. Create the .psm1 file that will host your code.
   Alternatively you can "dot source" your functions from within the .psm1 file.

4.	Using the `New-ModuleManifest` cmdlet, create the module manifest (.psd1 file)

5.  Now we will generate the help files nicely with the **PlatyPS** module.  
   Install the module from the PowerShell Gallery. Before trying to use this module, please visit the [PlatyPS project page](https://github.com/powershell/PlatyPS) in order to understand how to use it. Alternatively you can also read the `About_PlatyPS` help topic.  
   Complementary informations:
     
      * You can put your markdown files in a "Docs" folder located at the root of your module folder.
      * Put your XML file in the "En-Us" folder located at the root of your module folder.
      

6. At this stage your module is fully operational.  
   So: 
      - List all the available modules on your computer and check your module is visible,
      - Check the version number of your module is displayed,
      - Check the availability of the help on every command of your module,
      - Check the about_yourModule help topic is there.   

7. Create a ZIP file of your module and share it with a colleague.

8.	Install the module your colleague gives you and check its discovery.

