# Lab Git / GitHub
## Créer une repository sur GitHub
1. Créez-vous un compte sur http://github.com si vous n'en avez pas.

1. Authentifiez-vous auprès du site GitHub.com

1. Cliquez sur "New Repository" pour créer un nouveau dépôt.  
   a. Donner un nom au dépôt (par exemple : "GitLab")  
   b. Choisir un dépôt "public"  
   c. Cocher "Initialize this repository with a README  
   d. Choisir une licence (par exemple : GNU General Public License v3.0)  
   e. Cliquer sur le bouton "Create repository"  

## Installation et configuration du client Git
1. Installez le client Git en local sur votre machine:
```Powershell 
   Find-Package -name git -source chocolatey | Install-Package
```
Au besoin finissez l'installation manuellement. Pour valider que l'installation a été réalisée avec succès, tapez la commande `git` dans PowerShell. Celle-ci doit vous renvoyer la syntaxe d'utilisation de cette commande sans renvoyer d'erreur.

2. Créez et positionnez-vous dans le répertoire local qui contiendra la repository.  
Par exemple : 
```Powershell
   New-Item C:\GitRepo -type Directory
   Set-Location C:\GitRepo
```
3. Configurez votre nom d'utilisateur dans Git. [Plus d'infos en cliquant ici](https://help.github.com/articles/setting-your-username-in-git/)  
Par exemple : 
```
git config --global user.name "Arnaud Petitjean"
```
4. Configurez votre adresse mail dans Git. [Plus d'infos en cliquant ici](https://help.github.com/articles/setting-your-commit-email-address-in-git/)  
Par exemple : 
```
git config --global user.email "email@example.com"
```

## Clonage de la repository en local
1. Cliquez sur le bouton "Clone or download", puis copiez dans le presse papier l'adresse http indiquée (exemple : https://github.com/apetitjean/GitLab.git)

1. Clonez la repository avec la commande suivante : 
```Powershell
   git clone https://github.com/<Nom du repo>/GitLab.git
```

## Etablissement du lien de synchronisation entre GitHub et votre dépôt local
1. Placez vous dans le répertoire nouvellement apparu grâce à la commande précédente puis tapez :  
```
git remote -v
```
Cela indique que vous avez réalisé un "fork".

Vous devez en principe obtenir un résultat similaire à celui-ci:
```
origin  https://github.com/apetitjean/GitLab.git (fetch)
origin  https://github.com/apetitjean/GitLab.git (push)
```

2. Etablissement du lien de synchronisation. Tapez la commande :  
```
   git remote add upstream https://github.com/<Nom du repo>/GitLab.git
```
Collez l'URL que vous avez copié lorsque vous avez cloné la repository sur GitHub.

3. A l'aide de la commande `git remote -v` observez la configuration actuelle.

## Installation de Posh-Git

Le module Posh-Git vous permet de connaître les différences entre votre dépôt local et votre dépôt distant en un clin d'oeil. En effet votre Prompt variera en fonction. Testez vous allez vite comprendre ;-).

1. Installation à partir de la PSGallery
```Powershell
Install-Module posh-git
```

2. Configuration de votre profil pour que Posh-Git soit chargé au démarrage de PowerShell:  
```PowerShell
Add-PoshGitToProfile -AllHosts
```
A présent, votre prompt devrait avoir changé. Cela peut prendre quelques secondes. N'oubliez pas que la fonction Prompt est évaluée à chaque fois que vous pressez la touche Entrée.

## Mon premier commit
A présent que votre repository est correctement configurée, vous pouvez y déposer les fichiers composant votre module de Logs.
Pensez également à éditer le fichier Readme.md afin de mettre des détails sur ce que fait votre module ainsi que sur comment utiliser les commandes qui le compose.

Une fois cela fait, il faut commiter les changements et les envoyer dans la repository distante.

Pour se faire, taper les commandes suivantes: 
```Powershell
# Ajoute les fichiers dans la zone d'index
git add -A

# Création du commit
git commit -m "Message de description à propos du commit"

# Upload du commit dans GitHub
git push origin master
```

Connectez-vous sur le site GitHub et allez voir dans votre repository, vos fichiers devraient s'y trouver. :-)
