# Error Handling and Debugging
## Main goals

   - Understand the difference between terminating and non-terminating errors
   - Understand how to handle this two kind of errors
   - Know how to execute a script step-by-step
   - Know how to inspect live variables content during runtime
   - Know how to use breakpoints


## Exercice 1 - The respect of the rules

Some rules have been broken! So now it's time to put things in the right order.

Here's the script:
```Powershell
$a = 5
$b = 6
$c = "seven"
$d = 8

$x = $a + $b
$x = $x + $c
$x = $x + $d

$x
````

When you will be executing the script, you will receive the following error message:

```Powershell
Cannot convert value "seven" to type "System.Int32". Erreur : 
"Input string was not in a correct format."
At C:\scripts\Games07\Rules.ps1:7 char:10
+ $x = $x +  <<<< $c
19
```

To win the first part of this contest, add the code that will allow the script to run without displaying errors. But wait, this is not that simple: to make it, you must not modify any line of code. You can add lines but you cannot change or delete lines of existing code.  
Remember you are not trying to correct errors in the script but __you are just trying to execute the existing script without showing any error!__

To win the latest part of this contest, determine if an error occured during runtime. If it's the case, show the following error message "At least one error has been detected".

## Exercice 2 - Handling terminating errors

Here's a bit of script. Determine if the generated error is terminating or non-terminating by commenting each line in the try block then run the script and see what happens.


```PowerShell
try {
    remove-item c:\temp\nonexistingfile.txt
    1/0
    thisIsNotAValidCommand
    Write-Host 'Catching errors is a real sport!'
}
catch {
    "Error: $_"
}
finally {
    "I'm done!"
}
   ```

For each script execution, be able to say what kind of error occured.

Make sure that the `Remove-Item` cmdlet produces a terminating error (if it's not the case). Try to catch this specific error using a dedicated `Catch` block.


## Exercice 3 - Debugging

*** This exercice is to be done inside of VSCode. ***

In your `Write-Log` script or function, put some breakpoints into it (one at a time). 

Put a breakpoint on:
   - A line number,
   - On a function,
   - On a variable when the content change

If you're curious to see what happens under the hood, you can call the `Get-PsCallStack` cmdlet while the script execution is suspended. This cmdlet will give you information about the caller of your function or script.
