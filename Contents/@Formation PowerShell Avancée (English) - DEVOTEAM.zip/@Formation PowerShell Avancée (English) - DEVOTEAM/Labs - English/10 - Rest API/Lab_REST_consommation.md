﻿# Lab REST API

L'objectif de ce lab est de vous familiariser avec la consommation d'API REST. Vous allez, pour se faire, utiliser des services REST publics directement accessibles sur internet.

## On n'oublie pas les bonnes habitudes...
- Observez l'aide de la commande `Invoke-RestMethod`

## Bac à sable : jsonplaceholder.typicode.com
- Vous allez consommer l'API REST du site https://jsonplaceholder.typicode.com. Ce site est un site "bac à sable" dont l'objectif est de se familiariser avec REST. Toutes les opérations d'écriture/modification/suppression seront simulées et ne seront pas persistantes. Je vous invite à visiter la page d'accueil de ce site pour vous familiariser avec les usages de l'API REST qu'il propose.

- Afin de récupérer l'état d'avancement de la tâche portant l'id 1, effectuez une requête de type GET sur l'URI : https://jsonplaceholder.typicode.com/todos/1

- Récupérez les autres ressources (posts, comments, users) 

- Ajoutez un commentaires (comment) en utilisant la méthode POST

- Filtrez avec l'URI afin de ne récupérer que les posts de l'utilisateur 1

## Tradons de la crypto monnaie
 A l'aide des instructions données sur le site de la plateforme de trading POLONIEX, récupérez les cours en temps réel des crypto monnaies telles que le Bitcoin
  - https://docs.poloniex.com

## Moteur de recherches des API REST

Visitez le site ANY-API (https://any-api.com). Celui-ci répertorie un grand nombre d'API REST publiques. 
  N'hésitez pas à en choisir une ou deux et à les tester.

## Le coin des cinéphiles

A présent, vous allez récupérer des informations sur des films via  le site omdbapi.com (base de données cinématographique). Mais attention car ce n'est pas si simple car pour interagir avec ce service REST vous allez devoir vous authentifier via une clé d'API.

- Connectez-vous au site http://omdbapi.com et faites en sorte d'obtenir une clé d'API.
- Effectuez des requêtes pour rechercher des films par leur titre

Vous pouvez éventuellement essayer cette clé d'API: `d4f903ad`

- Téléchargez la jaquette d'un film