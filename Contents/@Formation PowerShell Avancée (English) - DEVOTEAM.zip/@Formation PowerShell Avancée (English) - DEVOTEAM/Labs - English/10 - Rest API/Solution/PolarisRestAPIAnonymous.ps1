Import-Module Polaris

$global:stock = Import-csv -Path "$PSScriptRoot\STOCKLIST.csv" -Delimiter ';'

New-PolarisRoute -Path '/material' -Method GET -ScriptBlock {
    $stock = $global:stock
    
    $division = $Request.Query['division']
    if ($division) {
        $stock = $stock | Where-Object {$_.'Division Desc' -eq $division}
    } 

    $gender = $Request.Query['gender']
    if ($gender) {
        $stock = $stock | Where-Object {$_.'PH1 - Gender Age Group' -eq $gender}
    } 

    Write-Host "Request = $($Request | convertto-json)"
    $Response.json(($stock | ConvertTo-Json))
    
}
Start-Polaris

# Exemple d'appel (à faire à partir d'une autre console que celle qui a lancé Polaris)
# Invoke-RestMethod -Uri 'http://localhost:8080/material?division=quiksilver&gender=women'
# Invoke-RestMethod -Uri 'http://localhost:8080/material?gender=women&division=DC%20Shoes'