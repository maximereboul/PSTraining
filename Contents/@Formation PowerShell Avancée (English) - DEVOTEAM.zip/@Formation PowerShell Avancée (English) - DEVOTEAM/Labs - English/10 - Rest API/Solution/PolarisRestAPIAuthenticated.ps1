# Implémentation d'une authentification par clé d'API
Import-Module Polaris

$global:stock = Import-csv -Path "$PSScriptRoot\STOCKLIST.csv" -Delimiter ';'

New-PolarisRoute -Path '/material' -Method GET -ScriptBlock {
    if ($Request.Headers['Authorization'] -ceq 'MaCleDAPISuperSecrete') {
        $stock = $global:stock

        $division = $Request.Query['division']
        if ($division) {
            $stock = $stock | Where-Object {$_.'Division Desc' -eq $division}
        } 

        $gender = $Request.Query['gender']
        if ($gender) {
            $stock = $stock | Where-Object {$_.'PH1 - Gender Age Group' -eq $gender}
        } 
        $Response.json(($stock | ConvertTo-Json))
    }
    else {
        $Result = [pscustomobject]@{
            Message = "Failed - Invalid Auth 401 Found!"
            Help    = "Contact System Administrator"
            Email   = "admin@acme.com"
        }
        $Response.Send(($Result | ConvertTo-Json))
    }

    # Utile pour déboguer
    Write-Host "Request = $($Request | ConvertTo-Json)"
}
Start-Polaris

# Attention, on ne peut pas consommer l'API à partir de la console qui a démarré Polaris !
# Marche car la clé d'API est passée
# Invoke-RestMethod -Uri 'http://localhost:8080/material?division=quiksilver&gender=women' -Headers @{'Authorization'='MaCleDAPISuperSecrete'}

# Ne fonctionne pas car la clé d'API n'est pas passée ou n'est pas bonne
# Invoke-RestMethod -Uri 'http://localhost:8080/material?division=quiksilver&gender=women' 