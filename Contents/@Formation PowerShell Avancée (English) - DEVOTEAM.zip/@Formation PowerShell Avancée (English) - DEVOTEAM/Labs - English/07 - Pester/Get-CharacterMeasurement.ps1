﻿function Get-CharacterMeasurement 
{
    [CmdletBinding()]
    Param (
        [String]$Str,
    
        [Switch]$ignoreWhiteSpace
    )

    if ($ignoreWhiteSpace) {
        $nbCars = $Str | Measure-Object -Character -IgnoreWhiteSpace
    }
    else {
        $nbCars = $Str | Measure-Object -Character
    }

    '{0} [{1}]' -f $Str, $nbCars.Characters
}
